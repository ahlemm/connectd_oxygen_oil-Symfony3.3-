<?php

namespace EspritBundle\Controller;

use EspritBundle\Form\userType;
use EspritBundle\Entity\user;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;

class UserController extends Controller
{
    public function AjouterAction(Request $request)
    {
        $user = new user();

        $form = $this->createForm(userType::class, $user);

        $form->handleRequest($request);
        if ($form->isvalid()) {
            $cnx = $this->getDoctrine()->getManager();
            $fr=$request->get('user');
            $email=$fr['email'];
            $res=$cnx->getRepository('EspritBundle:user')->findOneBy(array('email'=>$email));
            $row=count($res);
            if($row>=1)
            {echo 'existe';}
            else {
                $cnx->persist($user);
                $cnx->flush();
                $res=$cnx->getRepository('EspritBundle:user')->findOneBy(array('email'=>$email));
                $session=new Session();
                $session->set("users",$res);
                /*$session->set("id",$res->getId());
                $session->set("role",$res->getRole());*/
                return $this->redirectToRoute('Acceuil');
            }
        }

        return $this->render('EspritBundle:User:Ajout_user.html.twig', array('form' => $form->createview()));
    }


    public function  ConnecterAction()
    {

        return $this->render('EspritBundle:User:Connect_user.html.twig');
    }

    public function AuthentificationAction(Request $request)
    {


        $form = $this->createForm(userType::class);
        $form->handleRequest($request);
   if($request->isMethod("POST")) {
       $resForm = $request->get('user');
       $cnx = $this->getDoctrine()->getManager();
       $email=$resForm['email'];
       $pwd=$resForm['mdp'];
      $res=$cnx->getRepository('EspritBundle:user')->findOneBy(array('email'=>$email,'mdp'=>$pwd));
      $row=count($res);
      if($row==1)
      {
          $session=new Session();
          $session->set("users",$res);
          $session->set("id",$res->getId());
          $session->set("role",$res->getRole());
          $session->set("Email",$res->getEmail());

          return $this->redirectToRoute('Acceuil');
      }
      else
          echo 'vous n\'êtes pas inscrit';
   }


        return $this->render('EspritBundle:User:authentifier_user.html.twig', array('form' => $form->createview()));
    }



    public function AcceuilAction()
    {
        $cnx = $this->getDoctrine()->getManager();
        $resultat=$cnx->getRepository('EspritBundle:user')->findAll();
        return $this->render('EspritBundle:user:acceuil.html.twig');

    }
    public function DeconnexionAction()
    {
        $session=new Session();
        $session->set("users",null);
        $session->clear();
        return $this->redirectToRoute('User_Connecter');
    }
   /* public function ModifAction($id)
    {
        $session=new Session();
       // $id=$session->get("id");
        $cnx = $this->getDoctrine()->getManager();
        $resultat=$cnx->find('EspritBundle:user',$id);
        return $this->render('EspritBundle:user:Modifier_user.html.twig', array('res' => $resultat));

    }*/
    public function ModifierAction($id,Request $request)
    {
        $cnx = $this->getDoctrine()->getManager();
        $modif=$cnx->getRepository('EspritBundle:user')->find($id);
        $form = $this->createForm(userType::class,$modif);
        $form->handleRequest($request);
        if ($form->isvalid()) {
            $cnx->persist($modif);
            $cnx->flush();
            return $this->redirectToRoute('User_Afficher');
        }
        return $this->render('EspritBundle:user:Modifier_user.html.twig', array('form' => $form->createview()));

    }
    public function AfficheruserAction()
    {
        $cnx = $this->getDoctrine()->getManager();
        $res = $cnx->getRepository('EspritBundle:user')->findAll();
        return $this->render('EspritBundle:user:Afficher_user.html.twig', array('res' => $res));
    }

    public function SupprimeruserAction($id)
    {
        $cnx = $this->getDoctrine()->getManager();
        $delete=$cnx->getRepository('EspritBundle:user')->find($id);
        $cnx->remove($delete);
        $cnx->flush();
        return $this->redirectToRoute("User_Afficher");

    }
}