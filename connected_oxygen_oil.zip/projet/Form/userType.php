<?php

namespace EspritBundle\Form;

use Doctrine\DBAL\Types\StringType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;



use Symfony\Component\OptionsResolver\OptionsResolver;

class userType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom',TextType::class,array('label'=>false,'attr'=>array('placeholder'=>'nom',
                'class'=>'admin')))
            ->add('prenom',TextType::class,array('label'=>false,'attr'=>array('placeholder'=>'prenom',
                'class'=>'admin')))
            ->add('email',EmailType::class,array('label'=>false,'attr'=>array('placeholder'=>'Email',
                'class'=>'admin')))
            ->add('telephone',IntegerType::class,array('label'=>false,'attr'=>array('placeholder'=>'telephone',
        'class'=>'admin')))
            ->add('pays',ChoiceType::class,array('label'=>false,'choices'=>array('Tunisie'=>'Tunisie',
            'Algérie'=>'Algérie','Marroc'=>'Marroc'),
                'attr'=>array('class'=>'ville')))
            ->add('ville',ChoiceType::class,array('label'=>false,'choices'=>array('Tunis'=>'Tunis','Ariana'=>'Ariana'),
                'attr'=>array('class'=>'ville')))
            ->add('rue',TextType::class,array('label'=>false,'attr'=>array('placeholder'=>'rue',
                'class'=>'admin')))
            ->add('login',TextType::class,array('label'=>false,'attr'=>array('placeholder'=>'login',
                'class'=>'admin')))
            ->add('mdp' ,PasswordType::class,array('label'=>false,'attr'=>array('placeholder'=>'mot de passe',
                                                                                                     'class'=>'admin')))
            ->add('role',HiddenType::class,array('attr'=>array('value'=>'user')))
            ->add('dateAjout',HiddenType::class,array('attr'=>array('value'=>date('Y-m-d'))))
            ->add('etatcompte',HiddenType::class,array('attr'=>array('value'=>'0')))
        ;
    }
    
    /**
     * @param OptionsResolver $resolver
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'EspritBundle\Entity\user'
        ));
    }
}
