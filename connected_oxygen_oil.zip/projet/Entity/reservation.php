<?php

namespace EspritBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * reservation
 *
 * @ORM\Table(name="reservation")
 * @ORM\Entity(repositoryClass="EspritBundle\Repository\reservationRepository")
 */
class reservation
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="idDemandeur", type="integer")
     */
    private $idDemandeur;

    /**
     * @var int
     *
     * @ORM\ManyToOne(targetEntity="bouteille")
     */
    private $idBouteille;

    /**
     * @var string
     *
     * @ORM\Column(name="mtif", type="string", length=255)
     */
    private $mtif;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateDebut", type="datetime")
     */
    private $dateDebut;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateFin", type="datetime")
     */
    private $dateFin;



    /**
     * @var int
     *
     * @ORM\Column(name="etat", type="integer")
     */
    private $etat;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idDemandeur
     *
     * @param integer $idDemandeur
     *
     * @return reservation
     */
    public function setIdDemandeur($idDemandeur)
    {
        $this->idDemandeur = $idDemandeur;

        return $this;
    }

    /**
     * Get idDemandeur
     *
     * @return int
     */
    public function getIdDemandeur()
    {
        return $this->idDemandeur;
    }


    /**
     * Set mtif
     *
     * @param string $mtif
     *
     * @return reservation
     */
    public function setMtif($mtif)
    {
        $this->mtif = $mtif;

        return $this;
    }

    /**
     * Get mtif
     *
     * @return string
     */
    public function getMtif()
    {
        return $this->mtif;
    }

    /**
     * Set dateDebut
     *
     * @param \DateTime $dateDebut
     *
     * @return reservation
     */
    public function setDateDebut($dateDebut)
    {
        $this->dateDebut = $dateDebut;

        return $this;
    }

    /**
     * Get dateDebut
     *
     * @return \DateTime
     */
    public function getDateDebut()
    {
        return $this->dateDebut;
    }

    /**
     * Set dateFin
     *
     * @param \DateTime $dateFin
     *
     * @return reservation
     */
    public function setDateFin($dateFin)
    {
        $this->dateFin = $dateFin;

        return $this;
    }

    /**
     * Get dateFin
     *
     * @return \DateTime
     */
    public function getDateFin()
    {
        return $this->dateFin;
    }

    /**
     * Set etat
     *
     * @param integer $etat
     *
     * @return reservation
     */
    public function setEtat($etat)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return int
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * Set idBouteille
     *
     * @param \EspritBundle\Entity\bouteille $idBouteille
     *
     * @return reservation
     */
    public function setIdBouteille(\EspritBundle\Entity\bouteille $idBouteille = null)
    {
        $this->idBouteille = $idBouteille;

        return $this;
    }

    /**
     * Get idBouteille
     *
     * @return \EspritBundle\Entity\bouteille
     */
    public function getIdBouteille()
    {
        return $this->idBouteille;
    }
}
