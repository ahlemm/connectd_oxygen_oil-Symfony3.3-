<?php

namespace EspritBundle\Controller;

use EspritBundle\Form\annonceType;
use EspritBundle\Entity\annonce;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;

class AnnonceController extends Controller
{
    public function  AjouterAction(Request $request)
    {
        $annonce=new annonce();

        $form=$this->createForm(annonceType::class,$annonce);
        $form->handleRequest($request);
        if($form->isvalid())
        {$cnx=$this->getDoctrine()->getManager();
        $cnx->persist($annonce);
        $cnx->flush();}
        return $this->render('EspritBundle:Annonce:Ajouter.html.twig',array('form'=>$form->createview()));
    }
    public function  AfficherAction()
    {

        return $this->render('EspritBundle:Annonce:Afficher.html.twig');
    }

    public function  SupprimerAction()
    {

        return $this->render('EspritBundle:Annonce:Supprimer.html.twig');
    }
}
