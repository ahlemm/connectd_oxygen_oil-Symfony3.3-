<?php

namespace EspritBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EspritBundle extends Bundle
{
}
