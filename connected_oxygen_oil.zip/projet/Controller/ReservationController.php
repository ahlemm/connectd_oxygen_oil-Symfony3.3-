<?php

namespace EspritBundle\Controller;

use EspritBundle\Form\reservationType;
use EspritBundle\Entity\reservation;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
class ReservationController extends Controller
{
    public function AjouterAction(Request $request)
    {
        $reservation = new reservation();

        $form = $this->createForm(reservationType::class, $reservation);
        $form->handleRequest($request);
        if ($form->isvalid()) {
            $cnx = $this->getDoctrine()->getManager();
            $cnx->persist($reservation);
            $cnx->flush();
        }
        return $this->render('EspritBundle:Reservation:Ajout_reservation.html.twig', array('form' => $form->createview()));
    }


public function AnnulerAction($id)
{
    $cnx = $this->getDoctrine()->getManager();
    $delete=$cnx->getRepository('EspritBundle:reservation')->find($id);
    $cnx->remove($delete);
    $cnx->flush();
    return $this->redirectToRoute("Reservation_Afficher");



}
    public function AfficherAction()
    {
        $cnx = $this->getDoctrine()->getManager();
        $resultat=$cnx->getRepository('EspritBundle:reservation')->findAll();
        return $this->render('EspritBundle:reservation:Réservations.html.twig', array('res' => $resultat));

    }

    public function SupprimerAction($id)
    {
        $cnx = $this->getDoctrine()->getManager();
        $delete=$cnx->getRepository('EspritBundle:bouteille')->find($id);
        $cnx->remove($delete);
        $cnx->flush();
        return $this->redirectToRoute("Réservations");

    }





    public function  RéservationsAction()
    {

        $session=new Session();
        $id=$session->get("id");
        $role=$session->get("role");

        $cnx = $this->getDoctrine()->getManager();
        if ($role==1)
        {  $resultat=$cnx->getRepository('EspritBundle:reservation')->findAll();}
        else{ $resultat=$cnx->getRepository('EspritBundle:reservation')->findBy(array('idDemandeur'=>$id));}
        return $this->render('EspritBundle:Reservation:Réservations.html.twig',array('res'=>$resultat));
    }
}
