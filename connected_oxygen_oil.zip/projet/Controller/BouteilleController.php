<?php

namespace EspritBundle\Controller;

use EspritBundle\Form\bouteilleType;
use EspritBundle\Entity\bouteille;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;

class BouteilleController extends Controller
{
    public function AjouterAction(Request $request)
    {
        $bouteille = new bouteille();

        $form = $this->createForm(bouteilleType::class, $bouteille);
        $form->handleRequest($request);
        if ($form->isvalid()) {
            $cnx = $this->getDoctrine()->getManager();
            $cnx->persist($bouteille);
            $cnx->flush();
            return new Response('bouteille ajouté avec succée');
        }
        return $this->render('EspritBundle:bouteille:Ajout_bouteille.html.twig', array('form' => $form->createview()));
    }

    public function AfficherAction()
    {
        $session = new Session();
        $id = $session->get("id");
        $cnx = $this->getDoctrine()->getManager();
        $role = $session->get("role");
        if ($role == 1) {
            $resultat = $cnx->getRepository('EspritBundle:bouteille')->findAll();
        } else {
            $resultat = $cnx->getRepository('EspritBundle:bouteille')->findBy(array('idprop' => $id));
        }
        return $this->render('EspritBundle:bouteille:afficher.html.twig', array('res' => $resultat));


    }

    public function SupprimerAction($id)
    {
        $session = new Session();
        $cnx = $this->getDoctrine()->getManager();

        $delete = $cnx->getRepository('EspritBundle:bouteille')->find($id);
        $cnx->remove($delete);
        $cnx->flush();
        return $this->redirectToRoute("Bouteille_Afficher");

    }

    public function BouteillesAction()
    {

        return $this->render('EspritBundle:Bouteille:Bouteilles.html.twig');
    }

    public function ModifAction()
    {
        $session = new Session();
        $id = $session->get("id");
        $role = $session->get("role");

        $cnx = $this->getDoctrine()->getManager();
        if ($role == 1) {
            $resultat = $cnx->getRepository('EspritBundle:bouteille')->findAll();
        } else {
            $resultat = $cnx->getRepository('EspritBundle:bouteille')->findBy(array('idprop' => $id));
        }
        return $this->render('EspritBundle:bouteille:Modifier_bouteille.html.twig', array('res' => $resultat));

    }

    public function ModifierAction($id, Request $request)
    {
        $cnx = $this->getDoctrine()->getManager();
        $modif = $cnx->getRepository('EspritBundle:bouteille')->find($id);
        $form = $this->createForm(userType::class, $modif);
        $form->handleRequest($request);
        if ($form->isvalid()) {
            $cnx->persist($modif);
            $cnx->flush();
            return $this->redirectToRoute('Bouteille_Modifier');
        }
        return $this->render('EspritBundle:bouteille:Modifier_bouteille.html.twig', array('form' => $form->createview()));

    }
}

