<?php

namespace EspritBundle\Controller;

use EspritBundle\Form\messageType;
use EspritBundle\Entity\message;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;

class MessageController extends Controller
{
    public function AjouterAction(Request $request)
    {
        $message = new message();

        $form = $this->createForm(messageType::class,$message);
        $form->handleRequest($request);
        if ($form->isvalid()) {
            $cnx = $this->getDoctrine()->getManager();
            $cnx->persist($message);
            $cnx->flush();
        }
        return $this->render('EspritBundle:Annonce:Ajouter.html.twig', array('form' => $form->createview()));
    }
}