<?php

namespace EspritBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * bouteille
 *
 * @ORM\Table(name="bouteille")
 * @ORM\Entity(repositoryClass="EspritBundle\Repository\bouteilleRepository")
 */
class bouteille
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;



    /**
     * @var string
     *
     * @ORM\Column(name="idprop", type="string", length=255)
     */
    private $idprop;
    /**
     * @var string
     *
     * @ORM\Column(name="pression", type="string", length=255)
     */
    private $pression;
    /**
     * @var string
     *
     * @ORM\Column(name="disponibilite", type="string", length=255)
     */
    private $disponibilite;
    /**
     * @var string
     *
     * @ORM\Column(name="volume", type="string",length=255)
     */
    private $volume;
    /**
     * @var string
     *
     * @ORM\Column(name="prixlocation", type="string", length=255)
     */
    private $prixlocation;
    /**
     * @var string
     *
     * @ORM\Column(name="latitude", type="string", length=255)
     */
    private $latitude;
    /**
     * @var string
     *
     * @ORM\Column(name="longitude", type="string", length=255)
     */
    private $longitude;
    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * Set idprop
     *
     * @param string $idprop
     *
     * @return bouteille
     */
    public function setIdprop($idprop)
    {
        $this->idprop = $idprop;

        return $this;
    }

    /**
     * Get idprop
     *
     * @return string
     */
    public function getIdprop()
    {
        return $this->idprop;
    }

    /**
     * Set pression
     *
     * @param string $pression
     *
     * @return bouteille
     */
    public function setPression($pression)
    {
        $this->pression = $pression;

        return $this;
    }

    /**
     * Get pression
     *
     * @return string
     */
    public function getPression()
    {
        return $this->pression;
    }

    /**
     * Set disponibilite
     *
     * @param string $disponibilite
     *
     * @return bouteille
     */
    public function setDisponibilite($disponibilite)
    {
        $this->disponibilite = $disponibilite;

        return $this;
    }

    /**
     * Get disponibilite
     *
     * @return string
     */
    public function getDisponibilite()
    {
        return $this->disponibilite;
    }



    /**
     * Set prixlocation
     *
     * @param string $prixlocation
     *
     * @return bouteille
     */
    public function setPrixlocation($prixlocation)
    {
        $this->prixlocation = $prixlocation;

        return $this;
    }

    /**
     * Get prixlocation
     *
     * @return string
     */
    public function getPrixlocation()
    {
        return $this->prixlocation;
    }

    /**
     * Set latitude
     *
     * @param string $latitude
     *
     * @return bouteille
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;

        return $this;
    }

    /**
     * Get latitude
     *
     * @return string
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param string $longitude
     *
     * @return bouteille
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    /**
     * Get longitude
     *
     * @return string
     */
    public function getLongitude()
    {
        return $this->longitude;
    }

    /**
     * Set volume
     *
     * @param string $volume
     *
     * @return bouteille
     */
    public function setVolume($volume)
    {
        $this->volume = $volume;

        return $this;
    }

    /**
     * Get volume
     *
     * @return string
     */
    public function getVolume()
    {
        return $this->volume;
    }
}
