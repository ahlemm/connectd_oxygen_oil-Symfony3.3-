<?php

namespace EspritBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * message
 *
 * @ORM\Table(name="message")
 * @ORM\Entity(repositoryClass="EspritBundle\Repository\messageRepository")
 */
class message
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    /**
     * @var string
     *
     * @ORM\Column(name="idSender", type="string", length=255)
     */
    private $idSender;
    /**
     * @var int
     *
     * @ORM\Column(name="idReciever", type="integer")
     */
    private $idReciever;
    /**
     * @var string
     *
     * @ORM\Column(name="contenu", type="string")
     */
    private $contenu;
    /**
     * @var string
     *
     * @ORM\Column(name="date", type="string", length=255)
     */
    private $date;
    /**
     * @var string
     *
     * @ORM\Column(name="etat", type="string", length=255)
     */
    private $etat;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idSender
     *
     * @param string $idSender
     *
     * @return message
     */
    public function setIdSender($idSender)
    {
        $this->idSender = $idSender;

        return $this;
    }

    /**
     * Get idSender
     *
     * @return string
     */
    public function getIdSender()
    {
        return $this->idSender;
    }

    /**
     * Set idReciever
     *
     * @param integer $idReciever
     *
     * @return message
     */
    public function setIdReciever($idReciever)
    {
        $this->idReciever = $idReciever;

        return $this;
    }

    /**
     * Get idReciever
     *
     * @return integer
     */
    public function getIdReciever()
    {
        return $this->idReciever;
    }

    /**
     * Set contenu
     *
     * @param string $contenu
     *
     * @return message
     */
    public function setContenu($contenu)
    {
        $this->contenu = $contenu;

        return $this;
    }

    /**
     * Get contenu
     *
     * @return string
     */
    public function getContenu()
    {
        return $this->contenu;
    }

    /**
     * Set date
     *
     * @param string $date
     *
     * @return message
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return string
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set etat
     *
     * @param string $etat
     *
     * @return message
     */
    public function setEtat($etat)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return string
     */
    public function getEtat()
    {
        return $this->etat;
    }
}
